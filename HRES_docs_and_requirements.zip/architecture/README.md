# HRES Architecture

This folder contains architecture artifacts and diagrams for HRES.

See `../ARCHITECTURE.md` for the canonical architecture.
