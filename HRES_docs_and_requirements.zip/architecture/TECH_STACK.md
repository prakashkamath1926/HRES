# HRES — Technology Stack

| Layer | Technology |
|---|---|
| Language | Python |
| Backend | FastAPI |
| Agent orchestration | LangGraph |
| Validation | Pydantic |
| Heat intelligence | FortyGuard Temperature API |
| Weather | Open-Meteo / configured provider |
| Maps | Google Maps Platform / configured routing provider |
| Database | PostgreSQL |
| Cache/queue | Redis when justified |
| Frontend | React |
| Realtime | WebSockets |
| PDF/AAR | ReportLab |
| Testing | pytest |
| Deployment | Docker |
